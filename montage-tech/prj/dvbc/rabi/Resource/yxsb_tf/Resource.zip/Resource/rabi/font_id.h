
#ifndef _RSC_FONT_ID_H_
#define _RSC_FONT_ID_H_

#define FONT_ARIAL                                         1 

#endif
