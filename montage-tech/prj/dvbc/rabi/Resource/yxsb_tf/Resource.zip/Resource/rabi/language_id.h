
#ifndef _RSC_LANGUAGE_ID_H_
#define _RSC_LANGUAGE_ID_H_

#define LANGUAGE_ENGLISH                                   1 
#define LANGUAGE_SIMPLIFIED_CHINESE                        2 
#define LANGUAGE_FRENCH                                    3 
#define LANGUAGE_GERMAN                                    4 
#define LANGUAGE_ITALIAN                                   5 
#define LANGUAGE_SPANISH                                   6 
#define LANGUAGE_PORTUGUESE                                7 
#define LANGUAGE_RUSSIAN                                   8 
#define LANGUAGE_TURKISH                                   9 
#define LANGUAGE_POLISH                                   10 
#define LANGUAGE_ARABIC                                   11 
#define LANGUAGE_PERSIAN                                  12 

#endif
